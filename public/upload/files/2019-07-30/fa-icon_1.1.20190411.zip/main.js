import Vue from 'vue'
import App from './App'

// 弹窗组件
import popup from '@/components/uni-ui/uni-popup.vue'
Vue.component('uni-popup',popup)
// 图标组件
import faicon from '@/components/fa-icon/fa-icon.vue'
Vue.component('fa-icon',faicon)

Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
