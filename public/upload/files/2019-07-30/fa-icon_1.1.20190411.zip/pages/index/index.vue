<template>
	<view class="page">
		<uni-popup :show="type === 'details'" @hidePopup="togglePopup('')">
			<faiconpopup :type="deta" ></faiconpopup>
		</uni-popup>

		<view class="" v-for="(item,index) in list" :key="index">
			<view class="title">{{item.title}}</view>
			<rich-text :nodes="item.content"></rich-text>
			<scroll-view scroll-y="true">
				<view class="sk-content">
					<view class="sk-content-box" v-for="(item,index) in item.listType" :key="index" @click="togglePopup('details',item)">
						<fa-icon class="sk-content-item" :type="item" color="#2EC86A"></fa-icon>
					</view>
				</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	import faiconpopup from '@/components/fa-icon/fa-icon-popup.vue'
	export default {
		data() {
			return {
				type: '',
				deta: '',
				list: [{
						title: '网页',
						listType: [
							'address-book', 'address-book-o', 'address-card', 'address-card-o', 'adjust',
							'american-sign-language-interpreting', 'anchor', 'archive', 'area-chart', 'arrows', 'arrows-h', 'arrows-v',
							'asl-interpreting (别名)', 'assistive-listening-systems', 'asterisk', 'at', 'audio-description',
							'automobile (别名)', 'balance-scale', 'ban', 'bank (别名)', 'bar-chart', 'bar-chart-o (别名)', 'barcode',
							'bars', 'bath', 'bathtub (别名)', 'battery (别名)', 'battery-0 (别名)', 'battery-1 (别名)',
							'battery-2 (别名)', 'battery-3 (别名)', 'battery-4 (别名)', 'battery-empty', 'battery-full', 'battery-half',
							'battery-quarter', 'battery-three-quarters', 'bed', 'beer', 'bell', 'bell-o', 'bell-slash', 'bell-slash-o',
							'bicycle', 'binoculars', 'birthday-cake', 'blind', 'bluetooth', 'bluetooth-b', 'bolt', 'bomb', 'book',
							'bookmark',
							'bookmark-o', 'braille', 'briefcase', 'bug', 'building', 'building-o', 'bullhorn', 'bullseye', 'bus',
							'cab (别名)', 'calculator', 'calendar', 'calendar-check-o', 'calendar-minus-o', 'calendar-o',
							'calendar-plus-o',
							'calendar-times-o', 'camera', 'camera-retro', 'car', 'caret-square-o-down', 'caret-square-o-left',
							'caret-square-o-right', 'caret-square-o-up', 'cart-arrow-down', 'cart-plus', 'cc', 'certificate', 'check',
							'check-circle', 'check-circle-o', 'check-square', 'check-square-o', 'child', 'circle', 'circle-o',
							'circle-o-notch', 'circle-thin', 'clock-o', 'clone', 'close (别名)', 'cloud', 'cloud-download',
							'cloud-upload',
							'code', 'code-fork', 'coffee', 'cog', 'cogs', 'comment', 'comment-o', 'commenting', 'commenting-o', 'comments',
							'comments-o', 'compass', 'copyright', 'creative-commons', 'credit-card', 'credit-card-alt', 'crop',
							'crosshairs',
							'cube', 'cubes', 'cutlery', 'dashboard (别名)', 'database', 'deaf', 'deafness (别名)', 'desktop', 'diamond',
							'dot-circle-o', 'download', 'drivers-license (别名)', 'drivers-license-o (别名)', 'edit (别名)',
							'ellipsis-h',
							'ellipsis-v', 'envelope', 'envelope-o', 'envelope-open', 'envelope-open-o', 'envelope-square', 'eraser',
							'exchange', 'exclamation', 'exclamation-circle', 'exclamation-triangle', 'external-link',
							'external-link-square',
							'eye', 'eye-slash', 'eyedropper', 'fax', 'feed (别名)', 'female', 'fighter-jet', 'file-archive-o',
							'file-audio-o', 'file-code-o', 'file-excel-o', 'file-image-o', 'file-movie-o (别名)', 'file-pdf-o',
							'file-photo-o (别名)', 'file-picture-o (别名)', 'file-powerpoint-o', 'file-sound-o (别名)', 'file-video-o',
							'file-word-o', 'file-zip-o (别名)', 'film', 'filter', 'fire', 'fire-extinguisher', 'flag', 'flag-checkered',
							'flag-o', 'flash (别名)', 'flask', 'folder', 'folder-o', 'folder-open', 'folder-open-o', 'frown-o',
							'futbol-o',
							'gamepad', 'gavel', 'gear (别名)', 'gears (别名)', 'gift', 'glass', 'globe', 'graduation-cap',
							'group (别名)',
							'hand-grab-o (别名)', 'hand-lizard-o', 'hand-paper-o', 'hand-peace-o', 'hand-pointer-o', 'hand-rock-o',
							'hand-scissors-o', 'hand-spock-o', 'hand-stop-o (别名)', 'handshake-o', 'hard-of-hearing (别名)', 'hashtag',
							'hdd-o', 'headphones', 'heart', 'heart-o', 'heartbeat', 'history', 'home', 'hotel (别名)', 'hourglass',
							'hourglass-1 (别名)', 'hourglass-2 (别名)', 'hourglass-3 (别名)', 'hourglass-end', 'hourglass-half',
							'hourglass-o', 'hourglass-start', 'i-cursor', 'id-badge', 'id-card', 'id-card-o', 'image (别名)', 'inbox',
							'industry', 'info', 'info-circle', 'institution (别名)', 'key', 'keyboard-o', 'language', 'laptop', 'leaf',
							'legal (别名)', 'lemon-o', 'level-down', 'level-up', 'life-bouy (别名)', 'life-buoy (别名)', 'life-ring',
							'life-saver (别名)', 'lightbulb-o', 'line-chart', 'location-arrow', 'lock', 'low-vision', 'magic', 'magnet',
							'mail-forward (别名)', 'mail-reply (别名)', 'mail-reply-all (别名)', 'male', 'map', 'map-marker', 'map-o',
							'map-pin', 'map-signs', 'meh-o', 'microchip', 'microphone', 'microphone-slash', 'minus', 'minus-circle',
							'minus-square', 'minus-square-o', 'mobile', 'mobile-phone (别名)', 'money', 'moon-o', 'mortar-board (别名)',
							'motorcycle', 'mouse-pointer', 'music', 'navicon (别名)', 'newspaper-o', 'object-group', 'object-ungroup',
							'paint-brush', 'paper-plane', 'paper-plane-o', 'paw', 'pencil', 'pencil-square', 'pencil-square-o', 'percent',
							'phone', 'phone-square', 'photo (别名)', 'picture-o', 'pie-chart', 'plane', 'plug', 'plus', 'plus-circle',
							'plus-square', 'plus-square-o', 'podcast', 'power-off', 'print', 'puzzle-piece', 'qrcode', 'question',
							'question-circle', 'question-circle-o', 'quote-left', 'quote-right', 'random', 'recycle', 'refresh',
							'registered',
							'remove (别名)', 'reorder (别名)', 'reply', 'reply-all', 'retweet', 'road', 'rocket', 'rss', 'rss-square',
							's15 (别名)', 'search', 'search-minus', 'search-plus', 'send (别名)', 'send-o (别名)', 'server', 'share',
							'share-alt', 'share-alt-square', 'share-square', 'share-square-o', 'shield', 'ship', 'shopping-bag',
							'shopping-basket', 'shopping-cart', 'shower', 'sign-in', 'sign-language', 'sign-out', 'signal',
							'signing (别名)',
							'sitemap', 'sliders', 'smile-o', 'snowflake-o', 'soccer-ball-o (别名)', 'sort', 'sort-alpha-asc',
							'sort-alpha-desc', 'sort-amount-asc', 'sort-amount-desc', 'sort-asc', 'sort-desc', 'sort-down (别名)',
							'sort-numeric-asc', 'sort-numeric-desc', 'sort-up (别名)', 'space-shuttle', 'spinner', 'spoon', 'square',
							'square-o', 'star', 'star-half', 'star-half-empty (别名)', 'star-half-full (别名)', 'star-half-o', 'star-o',
							'sticky-note', 'sticky-note-o', 'street-view', 'suitcase', 'sun-o', 'support (别名)', 'tablet', 'tachometer',
							'tag', 'tags', 'tasks', 'taxi', 'television', 'terminal', 'thermometer (别名)', 'thermometer-0 (别名)',
							'thermometer-1 (别名)', 'thermometer-2 (别名)', 'thermometer-3 (别名)', 'thermometer-4 (别名)',
							'thermometer-empty', 'thermometer-full', 'thermometer-half', 'thermometer-quarter',
							'thermometer-three-quarters',
							'thumb-tack', 'thumbs-down', 'thumbs-o-down', 'thumbs-o-up', 'thumbs-up', 'ticket', 'times', 'times-circle',
							'times-circle-o', 'times-rectangle (别名)', 'times-rectangle-o (别名)', 'tint', 'toggle-down (别名)',
							'toggle-left (别名)', 'toggle-off', 'toggle-on', 'toggle-right (别名)', 'toggle-up (别名)', 'trademark',
							'trash', 'trash-o', 'tree', 'trophy', 'truck', 'tty', 'tv (别名)', 'umbrella', 'universal-access',
							'university',
							'unlock', 'unlock-alt', 'unsorted (别名)', 'upload', 'user', 'user-circle', 'user-circle-o', 'user-o',
							'user-plus', 'user-secret', 'user-times', 'users', 'vcard (别名)', 'vcard-o (别名)', 'video-camera',
							'volume-control-phone', 'volume-down', 'volume-off', 'volume-up', 'warning (别名)', 'wheelchair',
							'wheelchair-alt', 'wifi', 'window-close', 'window-close-o', 'window-maximize', 'window-minimize',
							'window-restore', 'wrench'
						]
					},
					{
						title: '辅助功能',
						listType: [
							'american-sign-language-interpreting', 'asl-interpreting (别名)', 'assistive-listening-systems',
							'audio-description', 'blind', 'braille', 'cc', 'deaf', 'deafness (别名)', 'hard-of-hearing (别名)',
							'low-vision', 'question-circle-o', 'sign-language', 'signing (别名)', 'tty', 'universal-access',
							'volume-control-phone', 'wheelchair', 'wheelchair-alt'
						]
					},
					{
						title: '手势',
						listType: [
							'hand-grab-o (别名)', 'hand-lizard-o', 'hand-o-down', 'hand-o-left', 'hand-o-right', 'hand-o-up',
							'hand-paper-o',
							'hand-peace-o', 'hand-pointer-o', 'hand-rock-o', 'hand-scissors-o', 'hand-spock-o', 'hand-stop-o (别名)',
							'thumbs-down', 'thumbs-o-down', 'thumbs-o-up', 'thumbs-up'
						]
					},
					{
						title: '运输',
						listType: [
							'ambulance', 'automobile (别名)', 'bicycle', 'bus', 'cab (别名)', 'car', 'fighter-jet', 'motorcycle',
							'plane',
							'rocket', 'ship', 'space-shuttle', 'subway', 'taxi', 'train', 'truck', 'wheelchair', 'wheelchair-alt'
						]
					},
					{
						title: '性别',
						listType: [
							'genderless', 'intersex (别名)', 'mars', 'mars-double', 'mars-stroke', 'mars-stroke-h', 'mars-stroke-v',
							'mercury', 'neuter', 'transgender', 'transgender-alt', 'venus', 'venus-double', 'venus-mars'
						]
					},
					{
						title: '文件类型',
						listType: [
							'file', 'file-archive-o', 'file-audio-o', 'file-code-o', 'file-excel-o', 'file-image-o',
							'file-movie-o (别名)',
							'file-o', 'file-pdf-o', 'file-photo-o (别名)', 'file-picture-o (别名)', 'file-powerpoint-o',
							'file-sound-o (别名)', 'file-text', 'file-text-o', 'file-video-o', 'file-word-o', 'file-zip-o (别名)'
						]
					},
					{
						title: '可旋转',
						content: '这些图标在fa-spin类的作用下表现优异',
						listType: [
							'circle-o-notch', 'cog', 'gear (别名)', 'refresh', 'spinner'
						]
					},
					{
						title: '表单',
						listType: [
							'check-square', 'check-square-o', 'circle', 'circle-o', 'dot-circle-o', 'minus-square', 'minus-square-o',
							'plus-square', 'plus-square-o', 'square', 'square-o'
						]
					},
					{
						title: '支付',
						listType: [
							'cc-amex', 'cc-diners-club', 'cc-discover', 'cc-jcb', 'cc-mastercard', 'cc-paypal', 'cc-stripe', 'cc-visa',
							'credit-card', 'credit-card-alt', 'google-wallet', 'paypal'
						]
					},
					{
						title: '图表',
						listType: [
							'area-chart', 'bar-chart', 'bar-chart-o (别名)', 'line-chart', 'pie-chart'
						]
					},
					{
						title: '货币',
						listType: [
							'bitcoin (别名)', 'btc', 'cny (别名)', 'dollar (别名)', 'eur', 'euro (别名)', 'gbp', 'gg', 'gg-circle',
							'ils',
							'inr', 'jpy', 'krw', 'money', 'rmb (别名)', 'rouble (别名)', 'rub', 'ruble (别名)', 'rupee (别名)',
							'shekel (别名)', 'sheqel (别名)', 'try', 'turkish-lira (别名)', 'usd', 'won (别名)', 'yen (别名)'
						]
					},
					{
						title: '文本编辑',
						listType: [
							'align-center', 'align-justify', 'align-left', 'align-right', 'bold', 'chain (别名)', 'chain-broken',
							'clipboard', 'columns', 'copy (别名)', 'cut (别名)', 'dedent (别名)', 'eraser', 'file', 'file-o',
							'file-text',
							'file-text-o', 'files-o', 'floppy-o', 'font', 'header', 'indent', 'italic', 'link', 'list', 'list-alt',
							'list-ol',
							'list-ul', 'outdent', 'paperclip', 'paragraph', 'paste (别名)', 'repeat', 'rotate-left (别名)',
							'rotate-right (别名)', 'save (别名)', 'scissors', 'strikethrough', 'subscript', 'superscript', 'table',
							'text-height', 'text-width', 'th', 'th-large', 'th-list', 'underline', 'undo', 'unlink (别名)'
						]
					},
					{
						title: '指示方向',
						listType: [
							'angle-double-down', 'angle-double-left', 'angle-double-right', 'angle-double-up', 'angle-down', 'angle-left',
							'angle-right', 'angle-up', 'arrow-circle-down', 'arrow-circle-left', 'arrow-circle-o-down',
							'arrow-circle-o-left',
							'arrow-circle-o-right', 'arrow-circle-o-up', 'arrow-circle-right', 'arrow-circle-up', 'arrow-down',
							'arrow-left',
							'arrow-right', 'arrow-up', 'arrows', 'arrows-alt', 'arrows-h', 'arrows-v', 'caret-down', 'caret-left',
							'caret-right', 'caret-square-o-down', 'caret-square-o-left', 'caret-square-o-right', 'caret-square-o-up',
							'caret-up', 'chevron-circle-down', 'chevron-circle-left', 'chevron-circle-right', 'chevron-circle-up',
							'chevron-down', 'chevron-left', 'chevron-right', 'chevron-up', 'exchange', 'hand-o-down', 'hand-o-left',
							'hand-o-right', 'hand-o-up', 'long-arrow-down', 'long-arrow-left', 'long-arrow-right', 'long-arrow-up',
							'toggle-down (别名)', 'toggle-left (别名)', 'toggle-right (别名)', 'toggle-up (别名)'
						]
					},
					{
						title: '视频播放',
						listType: [
							'arrows-alt', 'backward', 'compress', 'eject', 'expand', 'fast-backward', 'fast-forward', 'forward', 'pause',
							'pause-circle', 'pause-circle-o', 'play', 'play-circle', 'play-circle-o', 'random', 'step-backward',
							'step-forward', 'stop', 'stop-circle', 'stop-circle-o', 'youtube-play'
						]
					},
					{
						title: '标志',
						content: '<div style="font-size:12px;">·所有标志图标都分别是其所有者的注册商标。<br>·使用这些商标并不代表Font Awesome拥有它们。<br>·商标只应用在被提及相应的公司或产品时使用。<br><h3><b>特别注意!</b></h3><br>Adblock Plus 插件会通过设置“ Remove Social Media Buttons” 来移除 Font Awesome 的这些标志图标。然而我们并不会用一些特殊方法来强行显示。如果您认为这是一个错误，<br>请 <a href="https://adblockplus.org/en/bugs">向 Adblock Plus 报告这个问题。</a>在Adblock Plus修复这个问题之前，您需要自行修改这些图标的类名来解决这个问题。</div>',
						listType: [
							'500px', 'adn', 'amazon', 'android', 'angellist', 'apple', 'bandcamp', 'behance', 'behance-square',
							'bitbucket',
							'bitbucket-square', 'bitcoin (别名)', 'black-tie', 'bluetooth', 'bluetooth-b', 'btc', 'buysellads', 'cc-amex',
							'cc-diners-club', 'cc-discover', 'cc-jcb', 'cc-mastercard', 'cc-paypal', 'cc-stripe', 'cc-visa', 'chrome',
							'codepen', 'codiepie', 'connectdevelop', 'contao', 'css3', 'dashcube', 'delicious', 'deviantart', 'digg',
							'dribbble', 'dropbox', 'drupal', 'edge', 'eercast', 'empire', 'envira', 'etsy', 'expeditedssl', 'fa (别名)',
							'facebook', 'facebook-f (别名)', 'facebook-official', 'facebook-square', 'firefox', 'first-order', 'flickr',
							'font-awesome', 'fonticons', 'fort-awesome', 'forumbee', 'foursquare', 'free-code-camp', 'ge (别名)',
							'get-pocket', 'gg', 'gg-circle', 'git', 'git-square', 'github', 'github-alt', 'github-square', 'gitlab',
							'gittip (别名)', 'glide', 'glide-g', 'google', 'google-plus', 'google-plus-circle (别名)',
							'google-plus-official', 'google-plus-square', 'google-wallet', 'gratipay', 'grav', 'hacker-news', 'houzz',
							'html5', 'imdb', 'instagram', 'internet-explorer', 'ioxhost', 'joomla', 'jsfiddle', 'lastfm', 'lastfm-square',
							'leanpub', 'linkedin', 'linkedin-square', 'linode', 'linux', 'maxcdn', 'meanpath', 'medium', 'meetup',
							'mixcloud',
							'modx', 'odnoklassniki', 'odnoklassniki-square', 'opencart', 'openid', 'opera', 'optin-monster', 'pagelines',
							'paypal', 'pied-piper', 'pied-piper-alt', 'pied-piper-pp', 'pinterest', 'pinterest-p', 'pinterest-square',
							'product-hunt', 'qq', 'quora', 'ra (别名)', 'ravelry', 'rebel', 'reddit', 'reddit-alien', 'reddit-square',
							'renren', 'resistance (别名)', 'safari', 'scribd', 'sellsy', 'share-alt', 'share-alt-square', 'shirtsinbulk',
							'simplybuilt', 'skyatlas', 'skype', 'slack', 'slideshare', 'snapchat', 'snapchat-ghost', 'snapchat-square',
							'soundcloud', 'spotify', 'stack-exchange', 'stack-overflow', 'steam', 'steam-square', 'stumbleupon',
							'stumbleupon-circle', 'superpowers', 'telegram', 'tencent-weibo', 'themeisle', 'trello', 'tripadvisor',
							'tumblr',
							'tumblr-square', 'twitch', 'twitter', 'twitter-square', 'usb', 'viacoin', 'viadeo', 'viadeo-square', 'vimeo',
							'vimeo-square', 'vine', 'vk', 'wechat (别名)', 'weibo', 'weixin', 'whatsapp', 'wikipedia-w', 'windows',
							'wordpress', 'wpbeginner', 'wpexplorer', 'wpforms', 'xing', 'xing-square', 'y-combinator',
							'y-combinator-square (别名)', 'yahoo', 'yc (别名)', 'yc-square (别名)', 'yelp', 'yoast', 'youtube',
							'youtube-play', 'youtube-square'
						]
					},
					{
						title: '医疗',
						listType: [
							'ambulance', 'h-square', 'heart', 'heart-o', 'heartbeat', 'hospital-o', 'medkit', 'plus-square', 'stethoscope',
							'user-md', 'wheelchair', 'wheelchair-alt'
						]
					}
				]
			}
		},
		components: {
			faiconpopup
		},
		methods: {
			togglePopup(type, e) {
				this.type = type;
				this.deta = e;
			},
			tip(e) {
				uni.showToast({
					title: e,
					icon: 'none',
					duration: 5000
				})
			}
		}
	}
</script>

<style>
	scroll-view {
		min-height: 50upx;
		max-height: 500upx;
	}

	.sk-content {
		display: flex;
		flex-wrap: wrap;
	}

	.sk-content-box {
		display: flex;
		flex-direction: column;
		align-items: center;
		margin: 5upx 0;
		width: 10%;
		box-sizing: border-box;
	}

	.sk-content-item {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 70upx;
		height: 70upx;
		overflow: hidden;
		background: #EEE;
		border-radius: 10upx;
	}
</style>
