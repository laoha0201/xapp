<script>
	export default {
		onLaunch: function() {
			// console.log('App Launch')
		},
		onShow: function() {
			// console.log('App Show')
		},
		onHide: function() {
			// console.log('App Hide')
		}
	}
</script>

<style>
	.page {
		width: 100%;
		height: 100%;
		margin-bottom: 48upx;
		font-size: 28upx;
		line-height: 28upx;
		font-family: Times, serif;
	}

	.rows {
		/*横向布局*/
		display: flex;
		flex-direction: row;
		flex-wrap: nowrap;
		/*默认flex不换行*/
	}

	.columns {
		/*竖向布局*/
		display: flex;
		flex-direction: column;
	}

	.ellipsis {
		/* 溢出省略号 */
		width: 100%;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}

	.nowrap {
		/*溢出换行*/
		display: flex;
		flex-wrap: nowrap;
	}

	.nozoom {
		/* 不缩放 */
		flex-shrink: 0;
	}

	.space_between {
		/* flex 两端对齐 */
		display: flex;
		justify-content: space-between;
	}

	.center {
		/*文字‘—’居中*/
		display: flex;
		justify-content: center;
		text-align: center;
	}

	.center1 {
		/*文字‘|’居中*/
		display: flex;
		align-items: center;
	}

	.center2 {
		/*文字‘+’居中*/
		display: flex;
		justify-content: center;
		text-align: center;
		align-items: center;
	}

	.i {
		/*文字倾斜*/
		font-style: italic;
	}

	.b4 {
		/*文字加粗*/
		font-weight: 400;
	}

	.b7 {
		/*文字加粗*/
		font-weight: 700;
	}

	.h1 {
		font-size: 45upx;
		line-height: 47upx;
	}

	.h2 {
		font-size: 40upx;
		line-height: 42upx;
	}

	.h3 {
		font-size: 35upx;
		line-height: 37upx;
	}

	.h4 {
		font-size: 30upx;
		line-height: 32upx;
	}

	.h5 {
		font-size: 25upx;
		line-height: 27upx;
	}

	.h6 {
		font-size: 20upx;
		line-height: 22upx;
	}

	.image {
		/* 标准图片 */
		width: 100%;
		margin: 10upx 0;
	}

	.title {
		/* 标题 */
		color: #000;
		margin: 5upx 0;
		padding: 10upx 0 5upx 10upx;
		border-left: #008000 solid 20upx;
		font-weight: bold;
	}

	.subtitle {
		/* 副标题 */
		height: 60upx;
		background: #AAA;
	}

	.tips {
		/* 全局提示 */
		color: #000;
		padding: 5upx 20upx;
		font-size: 30upx;
		line-height: 35upx;
	}

	.red_tips {
		/* 全局警告提示 */
		color: #f00;
		padding: 5upx 20upx;
		font-size: 30upx;
		line-height: 35upx;
	}

	input {
		margin: 0;
		padding: 0;
		border: #000 solid 1upx;
	}
</style>
